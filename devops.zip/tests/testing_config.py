class TestingConfig:
    TOKEN = "f18dadb0-c911-46ac-854f-e552ef323cda"
    SQLALCHEMY_DATABASE_URI = "sqlite:///:memory"
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    TESTING = True